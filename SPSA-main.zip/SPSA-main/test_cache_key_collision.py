#!/usr/bin/env python3
"""
Test script for cache key collision fix
Demonstrates how different deals with similar activities now get unique cache keys
"""

import json
import logging
from datetime import datetime
from utils.cache import get_cache_manager, CacheManager

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_cache_key_uniqueness():
    """Test that different deals with similar activities get unique cache keys"""
    print("\n=== Testing Cache Key Uniqueness ===")
    
    # Create a cache manager for testing
    cache_manager = CacheManager()
    
    # Test scenarios with similar activities but different deals
    test_scenarios = [
        {
            'name': 'Deal A - Client Meeting',
            'deal_id': 'DEAL_A_001',
            'analysis_type': 'client',
            'prompt': 'Analyze client sentiment for meeting: "Thanks for the meeting"',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': True
        },
        {
            'name': 'Deal B - Client Meeting',
            'deal_id': 'DEAL_B_002',
            'analysis_type': 'client',
            'prompt': 'Analyze client sentiment for meeting: "Thanks for the meeting"',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': True
        },
        {
            'name': 'Deal A - Sales Analysis',
            'deal_id': 'DEAL_A_001',
            'analysis_type': 'sales',
            'prompt': 'Analyze sales performance for meeting: "Thanks for the meeting"',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': True
        },
        {
            'name': 'Deal B - Sales Analysis',
            'deal_id': 'DEAL_B_002',
            'analysis_type': 'sales',
            'prompt': 'Analyze sales performance for meeting: "Thanks for the meeting"',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': True
        },
        {
            'name': 'Deal A - No RAG Context',
            'deal_id': 'DEAL_A_001',
            'analysis_type': 'client',
            'prompt': 'Analyze client sentiment for meeting: "Thanks for the meeting"',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': False
        },
        {
            'name': 'Deal C - Different Model',
            'deal_id': 'DEAL_C_003',
            'analysis_type': 'client',
            'prompt': 'Analyze client sentiment for meeting: "Thanks for the meeting"',
            'model_name': 'Anthropic (claude-3-sonnet-20240229)',
            'include_rag_context': True
        }
    ]
    
    generated_keys = []
    
    for scenario in test_scenarios:
        # Generate cache key using the new comprehensive method
        cache_key = cache_manager._generate_llm_key(
            prompt=scenario['prompt'],
            model_name=scenario['model_name'],
            deal_id=scenario['deal_id'],
            analysis_type=scenario['analysis_type'],
            include_rag_context=scenario['include_rag_context'],
            cache_version="v1"
        )
        
        generated_keys.append({
            'scenario': scenario['name'],
            'cache_key': cache_key,
            'deal_id': scenario['deal_id'],
            'analysis_type': scenario['analysis_type'],
            'model_name': scenario['model_name'],
            'include_rag_context': scenario['include_rag_context']
        })
        
        print(f"✅ {scenario['name']}")
        print(f"   Cache Key: {cache_key[:32]}...")
        print(f"   Deal ID: {scenario['deal_id']}")
        print(f"   Analysis Type: {scenario['analysis_type']}")
        print(f"   Model: {scenario['model_name']}")
        print(f"   RAG Context: {scenario['include_rag_context']}")
        print()
    
    # Check for uniqueness
    unique_keys = set(key['cache_key'] for key in generated_keys)
    total_keys = len(generated_keys)
    
    print(f"📊 Cache Key Analysis:")
    print(f"   Total keys generated: {total_keys}")
    print(f"   Unique keys: {len(unique_keys)}")
    print(f"   Collisions: {total_keys - len(unique_keys)}")
    
    if len(unique_keys) == total_keys:
        print("✅ SUCCESS: All cache keys are unique!")
    else:
        print("❌ FAILURE: Cache key collisions detected!")
    
    return len(unique_keys) == total_keys

def test_old_vs_new_cache_keys():
    """Compare old vs new cache key generation"""
    print("\n=== Testing Old vs New Cache Key Generation ===")
    
    cache_manager = CacheManager()
    
    # Test data
    prompt = 'Analyze client sentiment for meeting: "Thanks for the meeting"'
    model_name = 'OpenAI (gpt-4-turbo-preview)'
    deal_id = 'DEAL_A_001'
    analysis_type = 'client'
    include_rag_context = True
    
    # Old method (simulated)
    def old_generate_llm_key(prompt: str, model_name: str) -> str:
        """Old cache key generation method"""
        import hashlib
        prompt_hash = hashlib.md5(prompt.encode('utf-8')).hexdigest()
        return f"{model_name}_{prompt_hash}"
    
    # New method
    new_key = cache_manager._generate_llm_key(
        prompt=prompt,
        model_name=model_name,
        deal_id=deal_id,
        analysis_type=analysis_type,
        include_rag_context=include_rag_context,
        cache_version="v1"
    )
    
    old_key = old_generate_llm_key(prompt, model_name)
    
    print(f"📝 Test Data:")
    print(f"   Prompt: {prompt}")
    print(f"   Model: {model_name}")
    print(f"   Deal ID: {deal_id}")
    print(f"   Analysis Type: {analysis_type}")
    print(f"   RAG Context: {include_rag_context}")
    print()
    
    print(f"🔑 Cache Key Comparison:")
    print(f"   Old Key: {old_key}")
    print(f"   New Key: {new_key[:32]}...")
    print(f"   Key Length (old): {len(old_key)} characters")
    print(f"   Key Length (new): {len(new_key)} characters")
    print()
    
    print(f"⚠️  Problem with Old Method:")
    print(f"   - Only uses prompt and model name")
    print(f"   - Different deals with same prompt get same key")
    print(f"   - No context about analysis type or RAG usage")
    print(f"   - Risk of serving wrong results to different deals")
    print()
    
    print(f"✅ Benefits of New Method:")
    print(f"   - Includes deal ID for uniqueness")
    print(f"   - Includes analysis type (sales/client)")
    print(f"   - Includes RAG context flag")
    print(f"   - Includes cache version for invalidation")
    print(f"   - Uses SHA256 for better collision resistance")
    print(f"   - Comprehensive context prevents wrong results")

def test_cache_integration():
    """Test cache integration with LLM responses"""
    print("\n=== Testing Cache Integration ===")
    
    cache_manager = CacheManager()
    
    # Test data
    test_data = [
        {
            'deal_id': 'DEAL_A_001',
            'analysis_type': 'client',
            'prompt': 'Analyze client sentiment: "Great meeting today"',
            'response': '{"sentiment": "positive", "score": 0.8}',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': True
        },
        {
            'deal_id': 'DEAL_B_002',
            'analysis_type': 'client',
            'prompt': 'Analyze client sentiment: "Great meeting today"',
            'response': '{"sentiment": "positive", "score": 0.8}',
            'model_name': 'OpenAI (gpt-4-turbo-preview)',
            'include_rag_context': True
        }
    ]
    
    for i, data in enumerate(test_data, 1):
        print(f"📝 Test {i}: {data['deal_id']} ({data['analysis_type']})")
        
        # Cache the response
        cache_success = cache_manager.cache_llm_response(
            prompt=data['prompt'],
            response=data['response'],
            model_name=data['model_name'],
            deal_id=data['deal_id'],
            analysis_type=data['analysis_type'],
            include_rag_context=data['include_rag_context'],
            cache_version="v1"
        )
        
        if cache_success:
            print(f"   ✅ Cached successfully")
        else:
            print(f"   ❌ Cache failed")
        
        # Retrieve the response
        cached_response = cache_manager.get_cached_llm_response(
            prompt=data['prompt'],
            model_name=data['model_name'],
            deal_id=data['deal_id'],
            analysis_type=data['analysis_type'],
            include_rag_context=data['include_rag_context'],
            cache_version="v1"
        )
        
        if cached_response:
            print(f"   ✅ Retrieved from cache: {cached_response}")
        else:
            print(f"   ❌ Not found in cache")
        
        print()

def test_cache_key_context():
    """Test cache key context components"""
    print("\n=== Testing Cache Key Context Components ===")
    
    cache_manager = CacheManager()
    
    # Base test data
    base_prompt = 'Analyze sentiment: "Good meeting"'
    base_model = 'OpenAI (gpt-4-turbo-preview)'
    
    # Test different contexts
    contexts = [
        {
            'name': 'Different Deal IDs',
            'variations': [
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': True},
                {'deal_id': 'DEAL_B_002', 'analysis_type': 'client', 'include_rag_context': True},
                {'deal_id': 'DEAL_C_003', 'analysis_type': 'client', 'include_rag_context': True}
            ]
        },
        {
            'name': 'Different Analysis Types',
            'variations': [
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': True},
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'sales', 'include_rag_context': True},
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': False}
            ]
        },
        {
            'name': 'Different RAG Context',
            'variations': [
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': True},
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': False}
            ]
        },
        {
            'name': 'Different Models',
            'variations': [
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': True, 'model': 'OpenAI (gpt-4-turbo-preview)'},
                {'deal_id': 'DEAL_A_001', 'analysis_type': 'client', 'include_rag_context': True, 'model': 'Anthropic (claude-3-sonnet-20240229)'}
            ]
        }
    ]
    
    for context in contexts:
        print(f"🔍 {context['name']}:")
        
        keys = []
        for variation in context['variations']:
            model = variation.get('model', base_model)
            
            cache_key = cache_manager._generate_llm_key(
                prompt=base_prompt,
                model_name=model,
                deal_id=variation['deal_id'],
                analysis_type=variation['analysis_type'],
                include_rag_context=variation['include_rag_context'],
                cache_version="v1"
            )
            
            keys.append(cache_key[:16])
            
            print(f"   {variation} -> {cache_key[:16]}...")
        
        # Check uniqueness
        unique_keys = set(keys)
        if len(unique_keys) == len(keys):
            print(f"   ✅ All keys unique")
        else:
            print(f"   ❌ Collision detected!")
        
        print()

def test_real_world_scenario():
    """Test real-world scenario with multiple deals"""
    print("\n=== Testing Real-World Scenario ===")
    
    cache_manager = CacheManager()
    
    # Simulate real-world scenario with multiple deals
    deals = [
        {
            'deal_id': 'DEAL_2024_001',
            'company': 'TechCorp Inc',
            'activities': [
                'Email: "Thanks for the proposal"',
                'Meeting: "Great discussion about implementation"',
                'Call: "Budget approved"'
            ]
        },
        {
            'deal_id': 'DEAL_2024_002',
            'company': 'DataFlow Systems',
            'activities': [
                'Email: "Thanks for the proposal"',
                'Meeting: "Great discussion about implementation"',
                'Call: "Budget approved"'
            ]
        },
        {
            'deal_id': 'DEAL_2024_003',
            'company': 'CloudTech Solutions',
            'activities': [
                'Email: "Thanks for the proposal"',
                'Meeting: "Great discussion about implementation"',
                'Call: "Budget approved"'
            ]
        }
    ]
    
    print("🏢 Simulating multiple deals with similar activities:")
    print()
    
    all_keys = []
    
    for deal in deals:
        print(f"📋 {deal['company']} ({deal['deal_id']}):")
        
        # Create activities text
        activities_text = '\n'.join(deal['activities'])
        
        # Test both client and sales analysis
        for analysis_type in ['client', 'sales']:
            # Create prompt
            prompt = f"Analyze {analysis_type} sentiment for {deal['company']}:\n{activities_text}"
            
            # Generate cache key
            cache_key = cache_manager._generate_llm_key(
                prompt=prompt,
                model_name='OpenAI (gpt-4-turbo-preview)',
                deal_id=deal['deal_id'],
                analysis_type=analysis_type,
                include_rag_context=True,
                cache_version="v1"
            )
            
            all_keys.append(cache_key)
            
            print(f"   {analysis_type.capitalize()} Analysis: {cache_key[:16]}...")
        
        print()
    
    # Check for collisions
    unique_keys = set(all_keys)
    total_keys = len(all_keys)
    
    print(f"📊 Real-World Scenario Results:")
    print(f"   Total cache keys: {total_keys}")
    print(f"   Unique keys: {len(unique_keys)}")
    print(f"   Potential collisions avoided: {total_keys - len(unique_keys)}")
    
    if len(unique_keys) == total_keys:
        print("✅ SUCCESS: No cache key collisions in real-world scenario!")
    else:
        print("❌ FAILURE: Cache key collisions detected in real-world scenario!")
    
    return len(unique_keys) == total_keys

def main():
    """Run all cache key collision tests"""
    print("🔐 Cache Key Collision Fix Test Suite")
    print("=" * 50)
    
    try:
        # Run all tests
        test1_passed = test_cache_key_uniqueness()
        test_old_vs_new_cache_keys()
        test_cache_integration()
        test_cache_key_context()
        test2_passed = test_real_world_scenario()
        
        print("\n" + "=" * 50)
        print("📋 Test Summary:")
        print(f"   Cache Key Uniqueness: {'✅ PASSED' if test1_passed else '❌ FAILED'}")
        print(f"   Real-World Scenario: {'✅ PASSED' if test2_passed else '❌ FAILED'}")
        
        if test1_passed and test2_passed:
            print("\n🎉 ALL TESTS PASSED!")
            print("\nCache Key Collision Fix Benefits:")
            print("- ✅ Different deals get unique cache keys")
            print("- ✅ Analysis types are properly separated")
            print("- ✅ RAG context inclusion is tracked")
            print("- ✅ Model differences are preserved")
            print("- ✅ Cache versioning for invalidation")
            print("- ✅ Comprehensive context prevents wrong results")
            print("- ✅ Production-safe for thousands of deals")
        else:
            print("\n❌ SOME TESTS FAILED!")
            
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        logger.error(f"Test execution failed: {e}")

if __name__ == "__main__":
    main() 