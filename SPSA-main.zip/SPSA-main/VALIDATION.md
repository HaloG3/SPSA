# LLM Response Validation System

## Overview

The LLM Response Validation System provides comprehensive validation for all LLM responses to ensure data integrity, prevent crashes, and maintain consistent data structures. Built with Pydantic models, it validates responses before they're used in the application.

## Problem Statement

### Current Risks
- **No guarantee response matches expected schema**: LLM responses may be malformed or incomplete
- **Missing fields cause KeyError exceptions**: Application crashes when expected fields are missing
- **Invalid values accepted**: Scores outside valid ranges (e.g., sentiment_score > 1.0) can cause issues
- **Type mismatches**: String values where numbers expected, or vice versa
- **Inconsistent data structures**: Different response formats from different LLM providers

### Solution Benefits
- **Guaranteed data integrity**: All responses conform to expected schemas
- **Graceful error handling**: Invalid responses are handled without crashes
- **Default value provision**: Missing fields get sensible defaults
- **Type safety**: All data types are validated and converted
- **Consistent interfaces**: Uniform response structure regardless of LLM provider

## Architecture

### Core Components

1. **Pydantic Models** (`models/validators.py`)
   - `ClientSentimentResponse`: Validates client sentiment analysis responses
   - `SalesSentimentResponse`: Validates sales sentiment analysis responses
   - `ActivityBreakdownItem`: Validates individual activity breakdowns
   - `ClientEngagementIndicators`: Validates client engagement data
   - `DealMomentumIndicators`: Validates deal momentum data

2. **ResponseValidator Class**
   - Main validation orchestrator
   - Handles preprocessing and error recovery
   - Provides default responses for failed validations

3. **Integration Layer** (`llm/llm_clients.py`)
   - Integrates validation into LLM response processing
   - Replaces old manual validation with Pydantic validation
   - Adds validation metadata to responses

## Validation Models

### BaseSentimentResponse
Base class for all sentiment responses with common fields:

```python
class BaseSentimentResponse(BaseModel):
    overall_sentiment: SentimentLevel
    sentiment_score: float = Field(..., ge=-1.0, le=1.0)
    confidence: float = Field(..., ge=0.0, le=1.0)
    activity_breakdown: Dict[str, ActivityBreakdownItem]
    reasoning: str = Field(..., min_length=10)
    buying_signals: List[str] = Field(default_factory=list)
    concern_indicators: List[str] = Field(default_factory=list)
    engagement_opportunities: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    analysis_metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
```

### ClientSentimentResponse
Extends base response with client-specific fields:

```python
class ClientSentimentResponse(BaseSentimentResponse):
    client_engagement_indicators: ClientEngagementIndicators
    decision_timeline: DecisionTimeline
    client_risk_level: RiskLevel
```

### SalesSentimentResponse
Extends base response with sales-specific fields:

```python
class SalesSentimentResponse(BaseSentimentResponse):
    deal_momentum_indicators: DealMomentumIndicators
    temporal_trend: str
    professional_gaps: List[str] = Field(default_factory=list)
    excellence_indicators: List[str] = Field(default_factory=list)
    risk_indicators: List[str] = Field(default_factory=list)
    opportunity_indicators: List[str] = Field(default_factory=list)
    benchmark_comparison: str = Field(default="")
    context_analysis_notes: List[str] = Field(default_factory=list)
```

## Validation Rules

### Score Validation
- **sentiment_score**: Must be between -1.0 and 1.0
- **confidence**: Must be between 0.0 and 1.0
- **activity sentiment scores**: Must be between -1.0 and 1.0

### Enum Validation
- **overall_sentiment**: Must be one of: exceptional_positive, positive, neutral, negative, critical_negative
- **response_pattern**: Must be one of: quick, normal, delayed
- **initiative_level**: Must be one of: proactive, responsive, passive
- **decision_readiness**: Must be one of: ready, evaluating, early_stage
- **decision_timeline**: Must be one of: immediate, near_term, long_term, unclear
- **client_risk_level**: Must be one of: low, medium, high

### Type Validation
- **Lists**: Must be actual lists, not strings or other types
- **Strings**: Must be non-empty when required
- **Numbers**: Must be valid numeric types
- **Dictionaries**: Must be actual dictionaries for nested structures

### Content Validation
- **reasoning**: Must be at least 10 characters long
- **key_indicators**: Must be list of non-empty strings
- **activity_breakdown**: Must be properly structured dictionary

## Usage Examples

### Basic Validation

```python
from models.validators import validate_llm_response

# Validate client response
client_response = {
    "overall_sentiment": "positive",
    "sentiment_score": 0.7,
    "confidence": 0.8,
    "activity_breakdown": {...},
    "client_engagement_indicators": {...},
    "decision_timeline": "near_term",
    "client_risk_level": "low",
    "reasoning": "Client shows strong engagement."
}

validated_response = validate_llm_response(client_response, "client", "DEAL_123")
print(f"Validated sentiment: {validated_response.overall_sentiment}")
```

### Handling Invalid Responses

```python
# Invalid response with missing fields
invalid_response = {
    "overall_sentiment": "positive"
    # Missing required fields
}

# Validation will provide defaults
validated_response = validate_llm_response(invalid_response, "client", "DEAL_456")
print(f"Default score: {validated_response.sentiment_score}")  # 0.0
print(f"Default confidence: {validated_response.confidence}")  # 0.5
```

### Direct Validator Usage

```python
from models.validators import get_response_validator

validator = get_response_validator()

# Validate client response
client_response = validator.validate_client_response(raw_data, "DEAL_789")

# Validate sales response
sales_response = validator.validate_sales_response(raw_data, "DEAL_101")
```

## Error Handling

### Graceful Degradation
When validation fails, the system provides safe default responses:

```python
# If validation fails, returns default response
default_response = validator._create_default_client_response(deal_id, error_message)
default_response = validator._create_default_sales_response(deal_id, error_message)
```

### Error Types Handled
1. **JSON Parsing Errors**: Invalid JSON structure
2. **Missing Required Fields**: Fields not present in response
3. **Invalid Data Types**: Wrong types for expected fields
4. **Out-of-Range Values**: Scores outside valid ranges
5. **Invalid Enum Values**: Unknown enum values
6. **Malformed Nested Structures**: Invalid activity breakdowns

### Logging
All validation events are logged:

```python
logger.info(f"Client response validation successful for deal {deal_id}")
logger.error(f"Client response validation failed for deal {deal_id}: {e}")
logger.warning(f"Invalid sentiment value: {v}, defaulting to neutral")
```

## Integration with LLM Clients

### Automatic Validation
All LLM responses are automatically validated:

```python
# In LLMClient._parse_and_validate_response()
validated_response = validate_llm_response(result, self.analysis_type, deal_id)
response_dict = validated_response.dict()

# Add validation metadata
response_dict['validation_metadata'] = {
    'validated': True,
    'validation_timestamp': datetime.utcnow().isoformat(),
    'analysis_type': self.analysis_type,
    'deal_id': deal_id
}
```

### Error Recovery
If validation fails, safe defaults are provided:

```python
except Exception as e:
    logger.error(f"Response validation failed for deal {deal_id}: {e}")
    
    # Return safe default response
    validator = get_response_validator()
    if self.analysis_type == "client":
        default_response = validator._create_default_client_response(deal_id, str(e))
    else:
        default_response = validator._create_default_sales_response(deal_id, str(e))
    
    return default_response.dict()
```

## Performance Considerations

### Optimized Validation
- **Compiled Pydantic models**: Fast validation using compiled validators
- **Lazy loading**: Validator instance created only when needed
- **Efficient preprocessing**: Minimal data transformation overhead

### Memory Usage
- **Default factories**: Lists and dicts created only when needed
- **Reference sharing**: Global validator instance shared across requests
- **Garbage collection**: Temporary objects cleaned up automatically

## Testing

### Test Coverage
The validation system includes comprehensive tests:

```bash
python test_response_validation.py
```

### Test Scenarios
1. **Valid Responses**: Properly formatted responses
2. **Missing Fields**: Responses with missing required fields
3. **Invalid Values**: Out-of-range scores and invalid enums
4. **Malformed Data**: Incorrect data types and structures
5. **Edge Cases**: Empty responses, null values, large responses
6. **Performance**: Large response validation performance
7. **Error Handling**: JSON parsing errors and validation failures

### Example Test Output
```
=== Testing Valid Client Response ===
✅ Valid client response validation successful
   Overall sentiment: positive
   Sentiment score: 0.7
   Confidence: 0.85
   Decision timeline: near_term
   Risk level: low

=== Testing Invalid Score Values ===
✅ Invalid scores handled gracefully
   Corrected sentiment score: 0.0
   Corrected confidence: 0.5
```

## Configuration

### Custom Validation Rules
You can extend validation models for custom requirements:

```python
class CustomSentimentResponse(BaseSentimentResponse):
    custom_field: str = Field(..., description="Custom validation field")
    
    @validator('custom_field')
    def validate_custom_field(cls, v):
        if not v.startswith('custom_'):
            raise ValueError("Custom field must start with 'custom_'")
        return v
```

### Validation Settings
Configure validation behavior:

```python
# In models/validators.py
class ResponseValidator:
    def __init__(self, strict_mode: bool = False):
        self.strict_mode = strict_mode  # Reject invalid responses instead of providing defaults
```

## Monitoring and Debugging

### Validation Metrics
Track validation performance and success rates:

```python
# Validation metadata in responses
{
    'validation_metadata': {
        'validated': True,
        'validation_timestamp': '2024-01-15T10:30:00Z',
        'analysis_type': 'client',
        'deal_id': 'DEAL_123'
    }
}
```

### Debug Information
Enable debug logging for detailed validation information:

```python
import logging
logging.getLogger('models.validators').setLevel(logging.DEBUG)
```

## Best Practices

### 1. Always Validate
Never trust LLM responses without validation:

```python
# Good: Always validate
validated_response = validate_llm_response(raw_response, analysis_type, deal_id)

# Bad: Direct usage without validation
result = json.loads(llm_response)  # May crash
```

### 2. Handle Validation Errors
Provide graceful error handling:

```python
try:
    validated_response = validate_llm_response(response_data, "client", deal_id)
except Exception as e:
    logger.error(f"Validation failed: {e}")
    # Use default response or retry
```

### 3. Monitor Validation Success
Track validation success rates:

```python
# Log validation metrics
if validated_response.analysis_metadata.get('validation_error'):
    logger.warning(f"Validation error for deal {deal_id}")
```

### 4. Test Edge Cases
Test with various response formats:

```python
# Test with minimal response
minimal_response = {"overall_sentiment": "neutral"}
validated = validate_llm_response(minimal_response, "client", "TEST")

# Test with malformed response
malformed_response = {"sentiment_score": "not_a_number"}
validated = validate_llm_response(malformed_response, "client", "TEST")
```

## Future Enhancements

### Planned Features
1. **Schema Versioning**: Support for multiple response schema versions
2. **Custom Validators**: User-defined validation rules
3. **Validation Caching**: Cache validation results for performance
4. **Real-time Monitoring**: Live validation metrics dashboard
5. **Auto-correction**: Intelligent response correction suggestions

### Extensibility
The validation system is designed for easy extension:

```python
# Add new response types
class NewAnalysisResponse(BaseSentimentResponse):
    new_field: str = Field(..., description="New analysis field")
    
# Add new validation rules
@validator('new_field')
def validate_new_field(cls, v):
    # Custom validation logic
    return v
```

## Conclusion

The LLM Response Validation System provides robust, reliable validation for all LLM responses, ensuring data integrity and preventing application crashes. With comprehensive error handling, performance optimization, and extensive testing, it provides a solid foundation for safe LLM response processing. 