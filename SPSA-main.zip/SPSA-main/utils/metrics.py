import threading
import time
from collections import defaultdict, Counter
from contextlib import contextmanager
from typing import Optional, Dict, Any, Callable, List
import math

class MetricsCollector:
    def __init__(self):
        self._lock = threading.Lock()
        self._counters = Counter()
        self._histograms = defaultdict(list)  # op_name -> list of latencies
        self._errors = Counter()  # error_type -> count
        self._token_usage = Counter()  # op_name -> tokens
        self._cache_stats = Counter()  # hit, miss, etc.
        self._failures = Counter()  # op_name -> count
        self._successes = Counter()  # op_name -> count

    def incr(self, key: str, value: int = 1):
        with self._lock:
            self._counters[key] += value

    def record_latency(self, op_name: str, latency: float):
        with self._lock:
            self._histograms[op_name].append(latency)

    def record_error(self, error_type: str):
        with self._lock:
            self._errors[error_type] += 1

    def record_token_usage(self, op_name: str, tokens: int):
        with self._lock:
            self._token_usage[op_name] += tokens

    def record_cache(self, result: str):
        with self._lock:
            self._cache_stats[result] += 1

    def record_success(self, op_name: str):
        with self._lock:
            self._successes[op_name] += 1

    def record_failure(self, op_name: str):
        with self._lock:
            self._failures[op_name] += 1

    def get_percentiles(self, op_name: str, percentiles=(50, 95, 99)) -> Dict[str, float]:
        with self._lock:
            data = self._histograms[op_name][:]
        if not data:
            return {f"p{p}": 0.0 for p in percentiles}
        data.sort()
        n = len(data)
        result = {}
        for p in percentiles:
            k = (n - 1) * (p / 100)
            f = math.floor(k)
            c = math.ceil(k)
            if f == c:
                val = data[int(k)]
            else:
                d0 = data[int(f)] * (c - k)
                d1 = data[int(c)] * (k - f)
                val = d0 + d1
            result[f"p{p}"] = val
        return result

    def get_counters(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._counters)

    def get_errors(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._errors)

    def get_token_usage(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._token_usage)

    def get_cache_stats(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._cache_stats)

    def get_success_failure_rates(self) -> Dict[str, Any]:
        with self._lock:
            result = {}
            for op in set(self._successes) | set(self._failures):
                succ = self._successes[op]
                fail = self._failures[op]
                total = succ + fail
                rate = succ / total if total else 0.0
                result[op] = {"success": succ, "failure": fail, "success_rate": rate}
            return result

    @contextmanager
    def track_operation(self, op_name: str, token_count: Optional[int] = None, cache_result: Optional[str] = None):
        start = time.time()
        try:
            yield
        except Exception as e:
            self.record_failure(op_name)
            self.record_error(type(e).__name__)
            raise
        else:
            self.record_success(op_name)
        finally:
            latency = time.time() - start
            self.record_latency(op_name, latency)
            if token_count is not None:
                self.record_token_usage(op_name, token_count)
            if cache_result is not None:
                self.record_cache(cache_result)

    def track(self, op_name: str):
        """Decorator for tracking function metrics."""
        def decorator(func: Callable):
            def wrapper(*args, **kwargs):
                token_count = kwargs.get('token_count')
                cache_result = kwargs.get('cache_result')
                with self.track_operation(op_name, token_count, cache_result):
                    return func(*args, **kwargs)
            return wrapper
        return decorator

    def get_metrics_snapshot(self) -> Dict[str, Any]:
        """Return a snapshot of all metrics for reporting."""
        with self._lock:
            return {
                "counters": dict(self._counters),
                "latencies": {op: self.get_percentiles(op) for op in self._histograms},
                "errors": dict(self._errors),
                "token_usage": dict(self._token_usage),
                "cache_stats": dict(self._cache_stats),
                "success_failure": self.get_success_failure_rates(),
            }

# Singleton instance
metrics_collector = MetricsCollector()
